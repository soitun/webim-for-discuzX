CHANGELOG
==============================

v0.1.0
-------------------------------

WebIM For DiscuzX first version

*	Only for utf8
